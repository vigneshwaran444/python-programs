# Naive-Bayes-classifier
A python program that implements the gaussian naive bayes algorithm
