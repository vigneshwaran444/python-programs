numbers=[]
strings=[]
names=["john","Eric","Jessica"]
 
#write your code here
second_name=None

#this code should write out the filled arrays and the second name in the name list(Eric).
print(numbers)
print(strings)
print("the second name on the name list is %s"%second_name)
