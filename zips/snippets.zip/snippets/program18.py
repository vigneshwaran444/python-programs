astring="hello world!"
print(astring.upper())
print(astring.lower())
astring="hello world!"
print(astring.startswith("hello"))
print(astring.endswith("asdfasdfasdf"))
astring="hello world!"
afewwords=astring.split(" ")
