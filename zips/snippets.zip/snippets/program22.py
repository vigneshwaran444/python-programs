statement= False
another_statement=True
if statement is True:
    print("world")
    # do something
    pass
elif another_statement is True:
    print("hello")
    # else if
    # do something else
    pass
else:
    print("hi")
    #do anotherthing
    pass
