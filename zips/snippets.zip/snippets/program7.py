remainder=11 %3
print(remainder)

squared= 7**2

cubed= 2**3
print(squared)
print(cubed)
