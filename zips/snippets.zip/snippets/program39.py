a=set(["jake","john","eric"])
b=set(["john","jill"])

print(a.intersection(b))
print(b.intersection(a))
