x=[1,2,3]
y=[1,2,3]
print(x == y)#Print out True
print(x is y)#Print out False
