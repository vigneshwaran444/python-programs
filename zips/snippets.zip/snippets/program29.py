class MyClass:
  variable ="blah"

print("hi")

def function(self):
  print("this is a message inside the class.")
