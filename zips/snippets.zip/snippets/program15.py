astring="hello world!"
print(astring[3:7])
