a=set(["jake","john","eric"])
b=set(["john","jill"])


print(a.union(b))
