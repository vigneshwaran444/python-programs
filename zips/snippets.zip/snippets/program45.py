#game.py
#import the draw module
from draw import draw_game


def main():
  result=play_game()
  draw_game(result)




