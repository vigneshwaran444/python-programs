one=1
two=2
three=one+two
print(three)

hello="hello"
world="world"

helloworld=hello+""+world
print(helloworld)
