import numpy as geek

array=geek.arange(8)
print("originalarray :\n",array)

array=geek.arange(8).reshape(2,4)
print("\narray reshaped with 2 rows and 4 columns :\n",array)

array=geek.arange(8).reshape(2,4)
print("\narray reshaped with 2 rows and 4 columns :\n",array)

array=geek.arange(8).reshape(2,2,2)
print("\n Original array reshaped to 3D :\n",array)
