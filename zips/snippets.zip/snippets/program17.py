astring= "hello world"
print(astring[::-1])
