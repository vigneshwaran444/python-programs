#Prints out 0,1,2,3,4

count=0
while count<5:
  print(count)
  count +=1 #this is the same as count=count+1
