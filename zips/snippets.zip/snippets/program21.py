name="john"
if name in["john","Rick"]:
  print("your name is either john or Rick.")
