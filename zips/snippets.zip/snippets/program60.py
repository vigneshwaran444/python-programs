 #single plot
fig,ax=plt.subplots()
ax.plot(x,y)
ax.set_title('A single plot')
