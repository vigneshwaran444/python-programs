number=1+2*3/4.0
print(number)
