a=["jake","john","eric"]
b=["john","jill"]

