class MyClass:
   variable = "blah"
     
   def function(self):
     print("This is a message inside the class.")


myobjectx = MyClass()

myobjectx.function()
