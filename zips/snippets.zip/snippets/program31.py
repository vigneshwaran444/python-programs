class MyClass:
    variable ="blah"

    def function(self):
      print("this is a message inside the class.")
 
myobjectx =MyClass()

print(myobjectx.variable)
