print(not False)#Prints out True
print((not False) == (False))#Prints out False
