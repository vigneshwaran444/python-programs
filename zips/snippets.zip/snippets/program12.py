astring="Hello world!"
print("single quotes are ")

print(len(astring))
