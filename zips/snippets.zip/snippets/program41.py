a=set(["jake","john","eric"])
b=set(["john","jill"])


print(a.difference(b))
print(b.difference(a))
