astring="hello world"
print(astring.count("l"))
