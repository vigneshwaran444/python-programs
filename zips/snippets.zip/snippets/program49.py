#
import pandas as pd

cars = pd.read_csv('cars.csv')

print(cars)
