primes =[2,3,5,7]
for prime in primes:
   print(prime)
