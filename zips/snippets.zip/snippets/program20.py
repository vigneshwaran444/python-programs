name="john"
age=23

if name =="john" and age==23:
   print("your name is john,and you are also 23 years old.")

if name == "john" or name =="Rick":
    print("yourname is either john or Rick.")
