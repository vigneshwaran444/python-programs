phonebook= {"john": 938463557625,"jack":7864539875735,"jill" :8759837535979}
for name,number in phonebook.items():
  print("phone number of %s is %d" % (name,number))
