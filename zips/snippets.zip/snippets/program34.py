phonebook ={}
phonebook["john"]=928869284927
phonebook["jack"]=9345678900
phonebook["jill"]=95644664666
print(phonebook)                                                                                                                      
