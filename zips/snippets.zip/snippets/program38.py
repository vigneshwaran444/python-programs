a=set(["jake","john","eric"])
print(a)
b=set(["john","jill"])
print(b)

