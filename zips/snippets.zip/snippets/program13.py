astring="Hello world!"
print(astring.index("o"))
