phonebook ={
      "john" :95579823945,
      "jack" :93948292825,
      "jill" :94832985943,

}

del phonebook["john"]
print(phonebook)

#OR
phonebook={
    "john" :93832284274,
    "jack" :93289285256,
    "jill" :87583758975

}
phonebook.pop("john")
print(phonebook)
