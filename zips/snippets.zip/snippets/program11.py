
mylist=[1,2,3]
print("A list:%s"% mylist)
