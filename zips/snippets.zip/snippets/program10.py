name ="John"
age= 23
print("%s is %d years old." %(name,age))
