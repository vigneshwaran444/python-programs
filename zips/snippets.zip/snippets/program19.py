x=2
print(x==2)#prints out True
print(x==3)#prints out False
print(x<3)#prints out True
