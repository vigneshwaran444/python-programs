x = 1
if x == 1:
	print("x is 1")
