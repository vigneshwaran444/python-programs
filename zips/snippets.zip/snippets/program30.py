class MyClass:
     variable = "blah"

print("hi! vicky")

def function(self):
    print("this is a message inside the class.")

myobjectx=MyClass()

myobjectx.variable
