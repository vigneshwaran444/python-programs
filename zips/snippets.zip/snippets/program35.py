phonebook={
     "john":934657665547,
     "jack":979776558769,
     "jill":92725417252

}
print(phonebook)
