a=set(["jake","john","eric"])
b=set(["john","jill"])


print(a.symmetric_difference(b))
print(b.symmetric_difference(a))
