even_numbers=[2,4,6,8]
odd_numbers=[1,3,5,7]
all_numbers=odd_numbers+even_numbers
print(all_numbers)
