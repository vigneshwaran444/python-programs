mylist=[]
mylist.append(1)
mylist.append(2)
mylist.append(3)
print(mylist[0]) #prints1
print(mylist[1]) #prints2
print(mylist[2]) #prints3

#prints out 1,2,3

for x in mylist:
     print(x)
